class Invite:

    def __init__(self, creator, event):
        self.creator = creator
        self.event = event
        self.accept = False