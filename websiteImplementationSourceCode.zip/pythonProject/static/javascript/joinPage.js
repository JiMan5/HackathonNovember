	function Chosen(){
		var element = -1;
	}

	



	function chooseEvent(element){
		var objDiv = document.getElementById("info-section");

		objDiv.scrollTop = 0;


		document.getElementById('info-section').style.marginRight = '0px';
		document.getElementById('info-section-title').innerHTML = element[4];

		document.getElementById('host').innerHTML ="Host: " + element[0];

		number = element[6];
		address = element[2].replace(/ /g,"+");
		city = element[7];
		TN =element[8];

		document.getElementById('location').innerHTML = "Address:" + " " + element[2] + " " + number ;

		document.getElementById('location').href = 'http://maps.google.com/maps?q=' + number + "+" + address + ",+" + city + ',+TN+' + TN;

		document.getElementById('calendar').innerHTML ="Date: " + element[1];

		document.getElementById('type').innerHTML ="Type: " + element[3].substring(0,element[3].length-4);

		document.getElementById('info-section-text').innerHTML = element[5];

		document.getElementById('myBar').style.width = (element[9]/element[10])*100 + '%';

		Chosen.element = element;

	}

	function closeThis(){
		document.getElementById('info-section').style.marginRight = '-600px';
	}

	var joined = false;
	function clickJoin(){
		if(joined){
			document.getElementById('Join').innerHTML = 'Join';
			document.getElementById('Join').style.transition = '0s';
			document.getElementById('Join').style.padding = '20px 53px';
			document.getElementById('myBar').style.transition = '0.7s';
			document.getElementById('myBar').style.width = (Chosen.element[9]/Chosen.element[10])*100 + '%';
			joined = false;

			var objDiv = document.getElementById("info-section");

			objDiv.scrollTop = 0;


			formData = document.getElementById('answers');
			
			var form = new FormData(formData);
			
            form.append('eventName', Chosen.element[4]);
            
			var xhr = new XMLHttpRequest();
            
            xhr.open('POST', '/remove_event', true);

            xhr.send(form);
			
		}

		else if(Chosen.element[9]<Chosen.element[10]){
			document.getElementById('Join').innerHTML = 'Leave';
			document.getElementById('Join').style.transition = '0s';
			document.getElementById('Join').style.padding = '20px 46px';
			document.getElementById('myBar').style.transition = '0.7s';
			document.getElementById('myBar').style.width = ((Chosen.element[9]+1)/Chosen.element[10])*100 + '%';
			joined = true;
			var objDiv = document.getElementById("info-section");

			objDiv.scrollTop = objDiv.scrollHeight;

			var objDiv = document.getElementById("info-section");

			objDiv.scrollTop = 0;

			

            formData = document.getElementById('answers');

			var form = new FormData(formData);

            form.append('eventName', Chosen.element[4]);

			var xhr = new XMLHttpRequest();
            
            xhr.open('POST', '/join_event', true);

            xhr.send(form);
		}
	}

	function clickLeave(){
		document.getElementById('Join').innerHTML = 'Join';
			document.getElementById('Join').style.transition = '0s';
			document.getElementById('Join').style.padding = '20px 53px';
			document.getElementById('myBar').style.transition = '0.7s';
			document.getElementById('myBar').style.width = (Chosen.element[9]/Chosen.element[10])*100 + '%';
			joined = false;

			var objDiv = document.getElementById("info-section");

			objDiv.scrollTop = 0;


			formData = document.getElementById('answers');
			
			var form = new FormData(formData);
			
            form.append('eventName', Chosen.element[4]);
            
			var xhr = new XMLHttpRequest();
            
            xhr.open('POST', '/remove_event', true);

            xhr.send(form);
	}

	var FirstTime = true
	function bookmark(){
		if(FirstTime){
			formData = document.getElementById('answers')

			var form = new FormData(formData)

			form.append('eventName',Chosen.element[4])

			var xhr = new XMLHttpRequest();

			xhr.open('POST', '/addBookmark',true);

			xhr.send(form);

			FirstTime = false;
		}
	}

	

	function openFilters(){
		document.getElementById('filters-senction').style.marginRight = '0px';
	}

	function closeFilters(){
		document.getElementById('filters-senction').style.marginRight = '-600px';
	}

	var open = false;
	function TypeFilters(){
		if(open){
			document.getElementById('types').style.transition = "0.5s";
			document.getElementById('types').style.opacity = "0";
			document.getElementById('types').style.visibility = "hidden";
			setTimeout(function(){
				document.getElementById('firstLine').style.marginTop = "20px";
			},500);
			open = false;
		}

		else{
			document.getElementById('firstLine').style.marginTop = "550px";
			setTimeout(function(){
				document.getElementById('types').style.transition = "0.5s";
				document.getElementById('types').style.opacity = "1";
				document.getElementById('types').style.visibility = "visible";
			},500);
			open = true;
		}
	}

	Array.prototype.remove = function() {
        var what, a = arguments, L = a.length, ax;
        while (L && this.length) {
            what = a[--L];
            while ((ax = this.indexOf(what)) !== -1) {
                this.splice(ax, 1);
            }
        }
        return this;
    };

	
	var chosenTypes = [];
	function ChooseFilter(div){


		if(chosenTypes.includes(div.innerHTML)){
			div.style.textDecoration = "none";
			chosenTypes.remove(div.innerHTML);
			
		}

		else{
			div.style.textDecoration = "underline";
			chosenTypes.push(div.innerHTML);

		}

		console.log(chosenTypes)

	}

	function invite(){
		searchName = document.getElementById('myInput')
		searchName.style.opacity = "1";
		searchName.style.visibility = "visible";
		searchName.style.transition = '0.5s';


	}

	
